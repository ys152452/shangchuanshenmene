# jcalculator
A simple calculator built with Javascript
