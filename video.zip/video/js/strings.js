const GLOBAL_STRINGS = {
  PLAY: "Play",
  PAUSE: "Pause",
  TOGGLE_FULL_SCREEN: "Toggle full screen",
  MUTE: "Mute",
  RESTART: "Restart",
  CAPTIONS: "Closed captions",
  REWIND: "Rewind",
  FORWARD: "Forward"
};
